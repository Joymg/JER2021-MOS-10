class GameManager{
    constructor(scene){
        GameManager.scene = scene;
    }
    static scene;
    static character;
    static character2;

    static bulletGroup1;
    static bulletGroup1;

    static woodenCrates;
    static ironCrates;
    static pits;
    static powerUps;

    static p1HpBar;
    static p2HpBar;
    static item1;
}